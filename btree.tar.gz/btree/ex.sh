#!/bin/bash
for s in 1 256 512 1024 1280 1536 1792 2048 ; 
do 
  echo run pth 1024x$s... ; 
  bin/pth/test $((1024*$s)) > ex/pth_$s.csv ; 
  cat ex/pth_$s.csv
  echo run cuda 1024x$s... ; 
  bin/cuda/test $((1024*$s)) > ex/cuda_$s.csv ; 
  cat ex/cuda_$s.csv
done ;
